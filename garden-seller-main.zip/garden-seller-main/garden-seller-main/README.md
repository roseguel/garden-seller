# Garden Seller

Esta página te permite comprar y vender plantas. Es un proyecto para Duoc UC.

## Asignación de tareas

#### Íconos

`Completado`: ✅

`No asignado`: 💠

`Trabajando`: ⚒️

`No comenzado`: 🛑

`No completado`: ❌

#### Tareas

| Tarea                      | Jenniffer  | Ariel   | Rodrigo  |
| :------------------------- | :--------: | :-----: | :------: |
| Mockup                     |     ✅     |   ✅   |    ✅    |
| Construcción HTML          |     ✅     |   ✅   |    ✅    |
| Construcción CSS           |     ✅     |   ✅   |    ✅    |
| Modelo de Datos            |     🛑     |   🛑   |    💠    |
| Construcción Base de Datos |     💠     |   🛑   |    💠    |
| Página Crud                |     💠     |   🛑   |    💠    |
| Formulario Productos       |     🛑     |   💠   |    💠    |

## Diseño
https://www.figma.com/file/aaE8ebfdFJJoUX4tbpcK67/Untitled?node-id=0%3A1
